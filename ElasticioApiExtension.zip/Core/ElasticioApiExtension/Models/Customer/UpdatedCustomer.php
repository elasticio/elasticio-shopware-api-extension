<?php

namespace Shopware\Models\Customer;

class UpdatedCustomer extends Customer
{

}