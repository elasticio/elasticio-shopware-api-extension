<?php

use Shopware\Components\Api\Exception as ApiException;

class Shopware_Controllers_Api_CustomerGroupByKey extends Shopware_Controllers_Api_CustomerGroups
{
    /**
     * Get one customergroup by key
     *
     * GET /api/customergroupbykey/{id}
     */
    public function getAction()
    {
        $id = $this->Request()->getParam('id');
        $result = $this->getCustomerGroupByKey($id);
        $this->View()->assign('data', $result);
        $this->View()->assign('success', true);
    }

    /**
     * @param  int $id
     * @return array|\Shopware\Models\Customer\Group
     * @throws \Shopware\Components\Api\Exception\ParameterMissingException
     * @throws \Shopware\Components\Api\Exception\NotFoundException
     */
    public function getCustomerGroupByKey($key)
    {
        $cgResource = $this->resource;

        $cgResource->checkPrivilege('read');
        if (empty($key)) {
            throw new ApiException\ParameterMissingException();
        }

        $builder = $cgResource->getRepository()->createQueryBuilder('customerGroup')
                ->select('customerGroup', 'd')
                ->leftJoin('customerGroup.discounts', 'd')
                ->where('customerGroup.key = :key')
                ->setParameter(':key', $key);
        $query = $builder->getQuery();
        $query->setHydrationMode($cgResource->getResultMode());

        /** @var $category \Shopware\Models\Customer\Group*/
        $result = $query->getOneOrNullResult($cgResource->getResultMode());
        if (!$result) {
            throw new ApiException\NotFoundException("CustomerGroup by key $key not found");
        }
        return $result;
    }
}
