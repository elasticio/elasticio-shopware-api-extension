<?php

use Shopware\Components\Api\Exception as ApiException;

class Shopware_Controllers_Api_OrdersByExternalId extends Shopware_Controllers_Api_Orders
{
    protected $resource = null;

    public function init()
    {
        $this->resource = \Shopware\Components\Api\Manager::getResource('orderByExternalId');
    }

    /*
    public function getAction()
    {
        $externalId = $this->Request()->getParam('id');

        Shopware()->Debuglogger()->info('ExternalId', $externalId);

        $id = $this->_getOrderIdByExternalId($externalId);

        $result = $this->resource->getOne($id);

        $this->View()->assign('data', $result);
        $this->View()->assign('success', true);
    }
    */

    /*
    private function _getOrderIdByExternalId($externalId)
    {
        $repository = Shopware()->Models()->getRepository('Shopware\Models\Attribute\Order');
        $attribute = $repository->findOneBy(array('elasticioExternalId' => $externalId));

        if (!$attribute) {
            throw new ApiException\NotFoundException("Order by external ID $externalId not found");
        }

        return $attribute->getOrderId();
    }
    */
}
